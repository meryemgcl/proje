﻿namespace EczaneOtomasyonu
{


    partial class DataSet2
    {
        partial class HastaDataTable
        {
        }

        partial class DataTable1DataTable
        {
        }
    }
}
