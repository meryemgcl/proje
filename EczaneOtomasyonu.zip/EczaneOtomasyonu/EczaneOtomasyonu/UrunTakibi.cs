﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Drawing.Imaging;


namespace EczaneOtomasyonu
{
    public partial class UrunTakibi : UserControl
    {

        OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=eczane_otomasyonu_veri1.accdb");
        OleDbCommand cmd;
        OleDbDataAdapter da;
        DataTable tablo;

        public void listele()
        {
            da = new OleDbDataAdapter("SELECT * FROM Ilaclar", con);
            tablo = new DataTable();
            da.Fill(tablo);
            dataGridView1.DataSource = tablo;
            temizle();
        }

        public void temizle()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            pictureBox1.ImageLocation = null;
        }

        public UrunTakibi()
        {
            InitializeComponent();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void UrunTakibi_Load(object sender, EventArgs e)
        {
            listele();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            {
                OpenFileDialog dosya = new OpenFileDialog();
                dosya.Filter = "Resim dosyaları | .jpg;.jpeg;*.png";
                if (dosya.ShowDialog() == DialogResult.OK)
                {
                    pictureBox1.ImageLocation = dosya.FileName;
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Lütfen Silmek İstediğiniz Kaydın Id'sini Giriniz ", "EKSİK GİRİŞ  HATASI ");
            }
            else
            {
                try
                {
                    con.Open();
                    cmd = new OleDbCommand("DELETE FROM Ilaclar WHERE Id = @Id", con);
                    cmd.Parameters.AddWithValue("@Id", int.Parse(textBox1.Text));
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Silme Tamam");
                    listele();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hata oluştu: " + ex.Message);
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                    {
                        con.Close();
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text) || string.IsNullOrEmpty(textBox3.Text) || string.IsNullOrEmpty(textBox4.Text) || string.IsNullOrEmpty(textBox5.Text) || string.IsNullOrEmpty(pictureBox1.ImageLocation))
            {
                MessageBox.Show("Lütfen Tüm Alanları Doldurun ", "EKSİK GİRİŞ  HATASI ");
            }
            else
            {
                try
                {
                    con.Open();
                    cmd = new OleDbCommand("INSERT INTO Ilaclar (Id, IlacKodu, IlacAdi, Fiyat, Adet, Resim) VALUES (@Id, @IlacKodu, @IlacAdi, @Fiyat, @Adet, @Resim)", con);
                    cmd.Parameters.AddWithValue("@Id", int.Parse(textBox1.Text));
                    cmd.Parameters.AddWithValue("@IlacKodu", int.Parse(textBox2.Text));
                    cmd.Parameters.AddWithValue("@IlacAdi", textBox3.Text);
                    cmd.Parameters.AddWithValue("@Fiyat", decimal.Parse(textBox4.Text));
                    cmd.Parameters.AddWithValue("@Adet", int.Parse(textBox5.Text));
                    cmd.Parameters.AddWithValue("@Resim", pictureBox1.ImageLocation);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Kayıt Yapıldı");
                    listele();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hata oluştu: " + ex.Message);
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                    {
                        con.Close();
                    }
                }
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            temizle();

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
                textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                textBox3.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
                textBox4.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
                textBox5.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
                pictureBox1.ImageLocation = dataGridView1.Rows[e.RowIndex].Cells[5].Value?.ToString();
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text) || string.IsNullOrEmpty(textBox3.Text) || string.IsNullOrEmpty(textBox4.Text) || string.IsNullOrEmpty(textBox5.Text) || string.IsNullOrEmpty(pictureBox1.ImageLocation))
            {
                MessageBox.Show("Lütfen Tüm Alanları Doldurun ", "EKSİK GİRİŞ  HATASI ");
            }
            else
            {
                try
                {
                    con.Open();
                    cmd = new OleDbCommand($"UPDATE Ilaclar SET IlacKodu= @IlacKodu, IlacAdi= @IlacAdi, Fiyat= @Fiyat, Adet= @Adet, Resim= @Resim WHERE Id = @Id", con);
                    cmd.Parameters.AddWithValue("@IlacKodu", textBox2.Text);
                    cmd.Parameters.AddWithValue("@IlacAdi", textBox3.Text);
                    cmd.Parameters.AddWithValue("@Fiyat", decimal.Parse(textBox4.Text));
                    cmd.Parameters.AddWithValue("@Adet", int.Parse(textBox5.Text));
                    cmd.Parameters.AddWithValue("@Resim", pictureBox1.ImageLocation);
                    cmd.Parameters.AddWithValue("@Id", int.Parse(textBox1.Text));
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Güncelleme Tamam");
                    listele();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hata oluştu: " + ex.Message);
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                    {
                        con.Close();
                    }
                }
            }
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            da = new OleDbDataAdapter($"SELECT * FROM Ilaclar WHERE IlacKodu LIKE '{textBox6.Text}%'", con);
            tablo = new DataTable();
            da.Fill(tablo);
            dataGridView1.DataSource = tablo;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}