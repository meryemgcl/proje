﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace EczaneOtomasyonu
{
    public partial class MainForm : Form
    {
        
        
        public MainForm()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Çıkmak istediğinden emin misin?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Çıkış yapmak istediğinizden emin misiniz?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Form1 loginForm = new Form1();
                loginForm.Show();

                this.Hide();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            panel3.Controls.Clear(); // Panel içeriğini temizle

            MusteriTakibi musteriForm = new MusteriTakibi();
            musteriForm.TopLevel = false; // Formu gömülü olarak kullanacağız
            musteriForm.FormBorderStyle = FormBorderStyle.None; // Kenarlık kaldır
            musteriForm.Dock = DockStyle.Fill; // Panele tam oturt

            panel3.Controls.Add(musteriForm); // Formu panele ekle
            musteriForm.Show(); // Formu göster
        }

        private void button1_Click(object sender, EventArgs e)
        {
            UrunTakibi urunTakibiUC = new UrunTakibi();

            LoadUserControl(urunTakibiUC);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SatisIslemleri satisIslemleriUC = new SatisIslemleri();
            LoadUserControl(satisIslemleriUC);
        }
        private void LoadUserControl(UserControl uc)
        {
            panel3.Controls.Clear();       // panel3 içini temizle
            uc.Dock = DockStyle.Fill;      // Paneli tamamen doldursun
            panel3.Controls.Add(uc);       // Panel içine ekle
        }

        private void urunTakibi1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
