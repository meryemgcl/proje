﻿using System;
using System.Windows.Forms;

namespace EczaneOtomasyonu
{
    public partial class MusteriTakibi : Form
    {
        private readonly DataSet2 ds = new DataSet2();
        private readonly DataSet2TableAdapters.HastaTableAdapter HastaTableAdapter = new DataSet2TableAdapters.HastaTableAdapter();

        public MusteriTakibi()
        {
            InitializeComponent();
        }

        private void musteritakibi_Load(object sender, EventArgs e)
        {
            comboBox1.Items.AddRange(new string[] { "SGK", "BAĞKUR", "YOK" });
            KayitlariGetir();
        }

        private void KayitlariGetir()
        {
            ds.Hasta.Clear();
            HastaTableAdapter.Fill(ds.Hasta);

            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.DataSource = ds.Hasta;

            // HastaID sütunu görünmüyorsa görünür yap
            if (dataGridView1.Columns.Contains("HastaID"))
            {
                dataGridView1.Columns["HastaID"].Visible = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                HastaTableAdapter.Insert(
                    textBox1.Text,                          // Adı
                    textBox2.Text,                          // Soyadı
                    long.Parse(textBox3.Text),              // TC
                    DateTime.Parse(maskedTextBox2.Text),    // Doğum Tarihi
                    comboBox1.Text,                         // Sigorta Türü
                    long.Parse(maskedTextBox1.Text)         // Telefon No
                );

                MessageBox.Show("Kayıt başarıyla eklendi.");
                KayitlariGetir();
            }
            catch (FormatException)
            {
                MessageBox.Show("Lütfen TC, Telefon No ve Doğum Tarihi alanlarını doğru formatta giriniz.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                try
                {
                    int secilenId = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["HastaID"].Value);
                    HastaTableAdapter.DeleteByID(secilenId);

                    MessageBox.Show("Kayıt silindi.");
                    KayitlariGetir();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Silme sırasında hata oluştu: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Lütfen silmek için bir kayıt seçin.");
            }
        }

        // Gereksiz boş event handler'lar (istersen silebilirsin)
        private void label1_Click(object sender, EventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
        private void label4_Click(object sender, EventArgs e) { }
        private void label5_Click(object sender, EventArgs e) { }
        private void textBox1_TextChanged(object sender, EventArgs e) { }
        private void textBox2_TextChanged(object sender, EventArgs e) { }
        private void textBox3_TextChanged(object sender, EventArgs e) { }
        private void panel1_Paint(object sender, PaintEventArgs e) { }
        private void panel2_Paint(object sender, PaintEventArgs e) { }
    }
}
